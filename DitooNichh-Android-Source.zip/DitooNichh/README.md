# DitooNichh Android Toolkit

Utility Android lokal tanpa AI API key. Fitur:
- Shizuku permission/status
- Ubah resolusi dan density/DPI menggunakan `wm`
- Reset resolusi dan density ke bawaan
- Peluncur hanya untuk package `com.dts.freefireth` dan `com.dts.freefiremax`
- Kurangi skala animasi sistem
- Tes koneksi dasar dengan ping
- Meminta Android memangkas cache aplikasi secara umum

## Persyaratan
- Android Studio terbaru yang mendukung Android Gradle Plugin 8.7.x
- JDK 17
- Android 8.0+ (minSdk 26)
- Shizuku terpasang. Untuk perangkat non-root Android 11+, aktifkan Developer options > Wireless debugging dan mulai Shizuku sesuai panduan resminya.

## Menjalankan
1. Ekstrak ZIP.
2. Buka folder `DitooNichh` di Android Studio.
3. Tunggu Gradle Sync.
4. Sambungkan HP atau gunakan emulator, lalu tekan Run.
5. Buka Shizuku dan mulai server melalui Wireless debugging.
6. Buka DitooNichh, tekan Periksa lalu Minta izin.
7. Coba pengaturan dengan nilai layar yang aman. Jika tampilan bermasalah, tekan Reset ke bawaan.

## Build APK
Di Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

CLI:
```bash
./gradlew assembleDebug
```

## Batasan yang disengaja
- Tidak memakai API key.
- Tidak memodifikasi file internal Free Fire atau Free Fire MAX.
- Tidak menyuntikkan kode, mengubah memori game, atau mengotomasi input game.
- DPI/resolusi berlaku ke tampilan perangkat dan dapat mengganggu UI; sediakan reset.
- Pengurangan animasi tidak meningkatkan sensitivitas fisik digitizer.
- Ping hanya diagnostik, tidak menjamin jaringan lebih cepat.
- `pm trim-caches` meminta sistem memangkas cache secara umum; tidak menjamin cache game tertentu terhapus. Aplikasi tidak menghapus data game/akun.
- Shizuku berjalan dengan identitas shell/ADB pada perangkat non-root; izin harus diberikan secara sadar oleh pengguna dan dapat dicabut.

## Catatan kompatibilitas
Contoh ini memakai `Shizuku.newProcess` untuk kesederhanaan; API tersebut deprecated pada versi API Shizuku modern. Untuk aplikasi produksi, migrasikan eksekusi perintah ke UserService/AIDL sesuai dokumentasi resmi Shizuku dan uji pada versi Android/vendor target.
