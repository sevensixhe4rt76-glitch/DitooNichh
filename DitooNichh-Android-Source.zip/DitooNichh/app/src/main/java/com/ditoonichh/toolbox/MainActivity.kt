package com.ditoonichh.toolbox

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

private const val SHIZUKU_REQUEST = 7001
private val gamePackages = listOf(
    "com.dts.freefireth" to "Free Fire",
    "com.dts.freefiremax" to "Free Fire MAX"
)
private val executor = Executors.newSingleThreadExecutor()

class MainActivity : ComponentActivity() {
    private var permissionGranted by mutableStateOf(false)
    private var shizukuRunning by mutableStateOf(false)
    private var statusText by mutableStateOf("Periksa status Shizuku untuk memulai.")
    private var outputText by mutableStateOf("Hasil perintah akan tampil di sini.")

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_REQUEST) {
            permissionGranted = grantResult == PackageManager.PERMISSION_GRANTED
            statusText = if (permissionGranted) "Izin Shizuku diberikan." else "Izin Shizuku ditolak."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        refreshShizukuState()
        setContent {
            DitooTheme {
                var darkMode by remember { mutableStateOf(true) }
                MaterialTheme(
                    colorScheme = if (darkMode) darkColorScheme(
                        primary = Color(0xFF9D7BFF),
                        secondary = Color(0xFF42D9FF),
                        background = Color(0xFF090B12),
                        surface = Color(0xFF141824)
                    ) else lightColorScheme(
                        primary = Color(0xFF5D45C7),
                        secondary = Color(0xFF087F9E)
                    )
                ) {
                    Surface(Modifier.fillMaxSize()) {
                        Column(
                            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Column {
                                    Text("DitooNichh", fontSize = 27.sp, fontWeight = FontWeight.Black)
                                    Text("DEVICE TOOLKIT  •  ANDROID", color = MaterialTheme.colorScheme.secondary, fontSize = 11.sp, letterSpacing = 1.4.sp)
                                }
                                IconButton(onClick = { darkMode = !darkMode }) {
                                    Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "Ganti tema")
                                }
                            }

                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(22.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Bolt, null, tint = MaterialTheme.colorScheme.secondary)
                                        Spacer(Modifier.width(8.dp))
                                        Text("Akses Wireless Debugging", fontWeight = FontWeight.Bold)
                                    }
                                    Text(statusText, style = MaterialTheme.typography.bodyMedium)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = { refreshShizukuState() }, modifier = Modifier.weight(1f)) { Text("Periksa") }
                                        OutlinedButton(onClick = {
                                            if (Shizuku.pingBinder()) {
                                                if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                                                    permissionGranted = true
                                                    statusText = "Izin Shizuku sudah aktif."
                                                } else {
                                                    Shizuku.requestPermission(SHIZUKU_REQUEST)
                                                }
                                            } else {
                                                statusText = "Jalankan Shizuku melalui Wireless Debugging terlebih dahulu."
                                                startActivity(Intent(Settings.ACTION_SETTINGS))
                                            }
                                        }, modifier = Modifier.weight(1f)) { Text("Minta izin") }
                                    }
                                    Text("Status: ${if (shizukuRunning) "Server aktif" else "Server belum aktif"} • ${if (permissionGranted) "Izin OK" else "Izin belum diberikan"}", style = MaterialTheme.typography.labelSmall)
                                }
                            }

                            SectionTitle("DISPLAY TUNER", "Atur resolusi dan DPI layar")
                            var width by remember { mutableStateOf("1080") }
                            var height by remember { mutableStateOf("2400") }
                            var dpi by remember { mutableStateOf("420") }
                            Card(shape = RoundedCornerShape(22.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(width, { width = it.filter(Char::isDigit).take(4) }, label = { Text("Lebar px") }, modifier = Modifier.weight(1f), singleLine = true)
                                        OutlinedTextField(height, { height = it.filter(Char::isDigit).take(4) }, label = { Text("Tinggi px") }, modifier = Modifier.weight(1f), singleLine = true)
                                    }
                                    OutlinedTextField(dpi, { dpi = it.filter(Char::isDigit).take(4) }, label = { Text("DPI / density") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    Text("Gunakan nilai yang didukung layar. Nilai ekstrem bisa membuat tampilan terpotong.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Button(onClick = {
                                        val w = width.toIntOrNull()
                                        val h = height.toIntOrNull()
                                        val d = dpi.toIntOrNull()
                                        if (w == null || h == null || d == null || w !in 320..5000 || h !in 480..8000 || d !in 100..1000) {
                                            outputText = "Nilai tidak valid. Lebar 320–5000, tinggi 480–8000, DPI 100–1000."
                                        } else runShell("wm size ${w}x${h} && wm density $d")
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Terapkan resolusi + DPI") }
                                    OutlinedButton(onClick = { runShell("wm size reset && wm density reset") }, modifier = Modifier.fillMaxWidth()) { Text("Reset ke bawaan") }
                                }
                            }

                            SectionTitle("GAME LAUNCHER", "Hanya Free Fire dan Free Fire MAX")
                            gamePackages.forEach { (pkg, title) ->
                                Card(shape = RoundedCornerShape(18.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.SportsEsports, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(30.dp))
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(title, fontWeight = FontWeight.Bold)
                                            Text(pkg, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Button(onClick = { launchGame(pkg, title) }) { Text("Buka") }
                                    }
                                }
                            }

                            SectionTitle("RESPONS & JARINGAN", "Pengaturan ringan, tanpa klaim ajaib")
                            Card(shape = RoundedCornerShape(22.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Button(onClick = {
                                        runShell("settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5; settings put global animator_duration_scale 0.5")
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Kurangi animasi sistem") }
                                    OutlinedButton(onClick = {
                                        runShell("settings get global window_animation_scale; settings get global transition_animation_scale; settings get global animator_duration_scale")
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Cek skala animasi") }
                                    OutlinedButton(onClick = {
                                        runShell("ping -c 4 -W 2 1.1.1.1")
                                    }, modifier = Modifier.fillMaxWidth()) { Text("Tes koneksi (ping)") }
                                    Text("Aplikasi tidak dapat menjamin ping lebih rendah atau mengubah sensitivitas fisik layar. Pengaturan animasi hanya mengurangi efek visual.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            SectionTitle("CACHE", "Pembersihan cache yang didukung sistem")
                            Card(shape = RoundedCornerShape(22.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Perintah ini meminta Android memangkas cache aplikasi secara umum; bukan menghapus data akun atau file game.")
                                    Button(onClick = { runShell("pm trim-caches 2G") }, modifier = Modifier.fillMaxWidth()) { Text("Minta Android pangkas cache") }
                                    Text("Pembersihan otomatis berkala tidak dijalankan diam-diam. Android membatasi akses cache aplikasi lain; hasil bergantung versi sistem dan kebijakan OEM.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            SectionTitle("LOG AKSI", "Output perintah terakhir")
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Text(outputText, modifier = Modifier.fillMaxWidth().padding(14.dp), fontSize = 12.sp)
                            }
                            Text("DitooNichh • Local utility • Tidak memakai API key", modifier = Modifier.align(Alignment.CenterHorizontally), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }

    private fun refreshShizukuState() {
        shizukuRunning = try { Shizuku.pingBinder() } catch (_: Exception) { false }
        permissionGranted = try {
            shizukuRunning && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) { false }
        statusText = when {
            !shizukuRunning -> "Shizuku belum aktif. Mulai server dari aplikasi Shizuku."
            permissionGranted -> "Shizuku aktif dan izin telah diberikan."
            else -> "Shizuku aktif. Berikan izin untuk menjalankan perintah."
        }
    }

    @Suppress("DEPRECATION")
    private fun runShell(command: String) {
        if (!Shizuku.pingBinder()) {
            outputText = "Gagal: server Shizuku tidak aktif."
            return
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            outputText = "Gagal: izin Shizuku belum diberikan."
            Shizuku.requestPermission(SHIZUKU_REQUEST)
            return
        }
        outputText = "Menjalankan perintah…"
        executor.execute {
            val result = try {
                val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText()
                val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText()
                val code = process.waitFor()
                "Exit code: $code\n${stdout.trim()}\n${stderr.trim()}".trim()
            } catch (e: Exception) {
                "Perintah gagal: ${e.message ?: "kesalahan tidak diketahui"}"
            }
            runOnUiThread { outputText = result.ifBlank { "Perintah selesai tanpa output." } }
        }
    }

    private fun launchGame(packageName: String, title: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            outputText = "$title dibuka."
        } else {
            outputText = "$title tidak ditemukan. Pastikan game terpasang dari sumber resmi."
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text(subtitle, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DitooTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF9D7BFF)), content = content)
}
